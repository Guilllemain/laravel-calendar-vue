<?php echo e($slot); ?>

<?php /**PATH /Users/yguillemain/code/laravel-calendar-vue/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>