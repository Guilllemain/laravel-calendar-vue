<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /Users/yguillemain/code/laravel-calendar-vue/resources/views/vendor/mail/text/button.blade.php ENDPATH**/ ?>