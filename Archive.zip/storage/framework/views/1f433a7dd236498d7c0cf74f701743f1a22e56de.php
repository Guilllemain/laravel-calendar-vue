<?php $__env->startSection('content'); ?>
            <div class="flex items-center flex-col">
                <h3 class="m-4"><?php echo e(__('Verification de votre adresse email')); ?></h3>

                <div class="">
                    <p class="text-center">
                        <?php echo e(__('Avant de pouvoir réserver un parking, merci de vérifier votre adresse email en cliquant sur le lien qui vient de vous être envoyé.')); ?>

                    </p>
                    <p class="text-center">
                        <?php echo e(__("Si vous n'avez pas reçu d'email")); ?>, <a href="<?php echo e(route('verification.resend')); ?>"><?php echo e(__('cliquez ici pour envoyer un nouvel email')); ?></a>.
                    </p>
                </div>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/yguillemain/code/laravel-calendar-vue/resources/views/auth/verify.blade.php ENDPATH**/ ?>