<?php $__env->startSection('content'); ?>
    <vue-calendar :user="<?php echo e($user); ?>"></vue-calendar>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/yguillemain/code/laravel-calendar-vue/resources/views/home.blade.php ENDPATH**/ ?>