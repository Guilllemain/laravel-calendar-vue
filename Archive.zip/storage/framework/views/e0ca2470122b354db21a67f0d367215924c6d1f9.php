<?php echo e($slot); ?>

<?php /**PATH /Users/yguillemain/code/laravel-calendar-vue/resources/views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>