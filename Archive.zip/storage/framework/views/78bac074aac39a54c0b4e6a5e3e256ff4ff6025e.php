<?php $__env->startSection('content'); ?>
<div class="flex justify-center items-center">
	<form class="md:w-1/3 max-w-sm" method="POST" action="<?php echo e(route('login')); ?>">
		<?php echo csrf_field(); ?>
		<div class="mb-6">
				<label class="block text-gray-500 font-bold mb-1 md:mb-0 pr-4" for="email">
					Email
				</label>
			<div class="">
				<input
					class="bg-gray-200 appearance-none border border-gray-200 rounded w-full py-2 px-4 text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-purple-500 <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
					type="email" id="email" name="email" value="<?php echo e(old('email')); ?>"
					required autocomplete="email" autofocus>
				<?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
				<span class="text-xs text-red-600" role="alert">
					<strong><?php echo e($message); ?></strong>
				</span>
				<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
			</div>

		</div>
		<div class="mb-4">
				<label class="block text-gray-500 font-bold mb-1 md:mb-0 pr-4" for="password">
					Mot de passe
				</label>
			<div class="">
				<input
					class="bg-gray-200 appearance-none border border-gray-200 rounded w-full py-2 px-4 text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-purple-500 <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
					id="password" type="password" name="password" required
					autocomplete="current-password">

				<?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
				<span class="text-xs text-red-600" role="alert">
					<strong><?php echo e($message); ?></strong>
				</span>
				<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
			</div>
		</div>

		<div class="md:flex md:items-center mb-2">
			<label class="block text-gray-500 font-bold" for="remember">
				<input class="mr-2 leading-tight" type="checkbox" name="remember"
					<?php echo e(old('remember') ? 'checked' : ''); ?>>
				<span class="text-sm">
					Se souvenir de moi
				</span>
			</label>
		</div>

		<button
			class="btn"
			type="submit">
				Se connecter
		</button>
		<div class="mt-2">
			<a class="hover:text-gray-700 text-sm text-gray-500 font-bold" href="<?php echo e(route('password.request')); ?>">
				Mot de passe oublié ?
			</a>
		</div>
	</form>

	<div class="ml-24 mb-8 md:w-1/3 max-w-sm">
		<div class="text-gray-500 font-bold mb-2">Pas encore de compte ?</div>
		<a class="btn" href="<?php echo e(route('register')); ?>">Créer un compte</a>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/yguillemain/code/laravel-calendar-vue/resources/views/auth/login.blade.php ENDPATH**/ ?>